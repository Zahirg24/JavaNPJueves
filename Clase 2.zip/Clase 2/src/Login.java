import java.util.Scanner;

public class Login {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// user: root	pass: 123
		
		System.out.println("\033[32m");
		System.out.println("**********************************************");
		System.out.println("*     G E S T I Ó N  D E  U S U A R I O S    *");
		System.out.println("**********************************************");
		System.out.println("\033[34m");
		System.out.print("Ingrese su nombre de Usuario: ");
		String user=new Scanner(System.in).next();
		System.out.println();
		System.out.print("Ingrese su Clave: ");
		String pass=new Scanner(System.in).next();
		System.out.println("\u001B[0m");
		
		//System.out.println("User: "+user+", pass: "+pass);
		
		// el método equals() permite comparar Strings
		
		
		
//		if(user.equals("root")) {
//			if(pass.equals("123")) {
//				System.out.println("\033[32mBienvenidos al Sistema!\u001B[0m");
//			} else {
//				System.out.println("\033[31mClave Incorrecta!\u001B[0m");
//			}
//		} else {
//			System.out.println("\033[31mUsuario Incorrecto!\u001B[0m");
//		}
		
		
		if(user.equals("root") && pass.equals("123")) 	System.out.println("\033[32mBienvenidos al Sistema!\u001B[0m");
		if(user.equals("root") && !pass.equals("123")) 	System.out.println("\033[31mClave Incorrecta!\u001B[0m");
		if(!user.equals("root")) 						System.out.println("\033[31mUsuario Incorrecto!\u001B[0m");
		
		
		
		
	
		
		
	}
}
