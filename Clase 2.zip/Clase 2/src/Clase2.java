
public class Clase2 {

	public static void main(String[] args) {
		// Clase 2

		/*
		 * Operadores Relacionales
		 * 
		 * == Equals (Comparación) != Not Equals (No Igual) ! Not < <= >= >
		 * 
		 */
		/*
		 * Operadores Logicos
		 * 
		 * && AND //shift 6 || OR //altgr 1
		 */

		/*
		 * 
		 * Tabla de Verdad
		 * 
		 * X Y OR AND F F F F F V V F V F V F V V V V
		 * 
		 */

		boolean log1 = true;
		boolean log2 = false;
		int nro1 = 5;
		int nro2 = 7;

		System.out.println(nro1 + 8 <= nro2 || !!log2 || nro1 != 5 || !(log2 && log1 && !log1 && nro1 == nro2));

		System.out.println(nro1 + 8 <= nro2 && !!log2 && nro1 != 5 && !(log2 || log1 || !log1 || nro1 == nro2));

		// Operadores Binarios & (AND) | (OR)

		System.out.println(log1 | log2); // true
		System.out.println(log2 & log1); // false

		// Estructura condicional IF
		/*
		 * if( expresión booleana ){
		 * 
		 * Sentencias ......
		 * 
		 * }
		 * 
		 */

		if (nro1 == 6) {
			System.out.println("Verdad 1");
		}

		if (log1) {
			System.out.println("Verdad 2");
		}

		if (log1 == true) {
			// código indentado
			System.out.println("Verdad 3");
			System.out.println("Hola a todos");
		}

		// uso de llaves
		// Modo recomendado por microsoft
		if (!log1) {
			System.out.println("Verdad 4");
		}

		// Modo abreviado de usar las llaves
		if (log1)
			System.out.println("Verdad 5");
		System.out.println("Fin del programa!");
		
		
		// Estructura If Else
		if(!log1) {
			System.out.println("Verdad 6");
		} else {
			System.out.println("Falso 6");
		}
		
		// Modo de llaves expandido
		if(!log1) 
		{
			System.out.println("Verdad 7");
		} 
		else 
		{
			System.out.println("Falso 7");
		}
		
		// Modo abreviado de llaves
		if(log1) 	System.out.println("Verdad 8");
		else 		System.out.println("Falso 8");
		
		
		
		
	}

}
