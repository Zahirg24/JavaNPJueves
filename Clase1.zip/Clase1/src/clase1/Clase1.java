package clase1;

public class Clase1 {

    public static void main(String[] args) {    // punto de entrada del proyecto
        /*
        Curso:  Java para no Programadores 15 hs.
        Días:   Jueves 10:00 a 13:00 hs.
        Profe:  Carlos Rios      carlos.rios@educacionit.com
        
        Materiales:     alumni.educacionit.com
                        user: email
                        pass: dni
        
        GitHub:         https://github.com/crios2020/JavaNPJueves
        
        Software:   JDK 11.X o superior     https://www.oracle.com/ar/java/technologies/javase-downloads.html
        
                    Eclipse IDE for Java Enterprise javaEE https://www.eclipse.org/
        
        JDK: Java Development Kit (Kit de Desarrollo Java)
        
        IDE: Integrated Development Enviroment  (Entorno de Desarrollo Integrado)
        Eclipse - (STS) Spring Tools Suite - Netbeans - IntelliJ - JDeveloper
        
        */
        System.out.println("");
        System.out.println("Hola Mundo!");      // imprime en consola
        
        //Lenguaje case sensitive
        // ; es el terminador de sentencias
        
        
        
    }
    
}
