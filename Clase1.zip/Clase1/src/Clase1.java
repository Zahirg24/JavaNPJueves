
public class Clase1 {

	public static void main(String[] args) { 

		/*
		 * Curso: Java para no Programadores 15 hs. Días: Jueves 10:00 a 13:00 hs.
		 * Profe: Carlos Rios carlos.rios@educacionit.com
		 * 
		 * Materiales: alumni.educacionit.com user: email pass: dni
		 * 
		 * GitHub: https://github.com/crios2020/JavaNPJueves
		 * 
		 * Software: JDK 11.X o superior
		 * https://www.oracle.com/ar/java/technologies/javase-downloads.html
		 * 
		 * Eclipse IDE for Java Enterprise javaEE https://www.eclipse.org/
		 * 
		 * JDK: Java Development Kit (Kit de Desarrollo Java)
		 * 
		 * IDE: Integrated Development Enviroment (Entorno de Desarrollo Integrado)
		 * Eclipse - (STS) Spring Tools Suite - Netbeans - IntelliJ - JDeveloper
		 * 
		 */

		// Comentarios de una sola linea

		/*
		 * Bloque de comentarios
		 */

		System.out.println("Hola Mundo!"); // imprime en consola

		// Lenguaje case sensitive
		// ; es el terminador de sentencias
		
		// Eclipse
		// syso + ctrol espacio: atajo para System.out.println();
		
		// Netbeans
		// sout	tab: atajo para System.out.println();
		
		System.out.println("Educación IT");
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.println("4");
		System.out.println("Hoy es Jueves!");
		
		
		/*
		 	Hola Mundo!
		 	Educación IT
		 	1234
		 	Hoy es Jueves!
		 */
		
		// Variables
		
		// Java C++ C# Visual Basic son lenguajes tipado fuertes
		// PHP javascript python son lenguajes de tipado debil
		
		// variables enteras
		int a;			//declarar la variable a
		a=2;			//asignar valor a variable a
		
		int b=4;		//declarar y asignar la variable b;
		
		int c=a+b;
		
		int d=5,f=45,e=23,s=26,g=39;	//declaración y asignación  multiples de variables
		
		System.out.println(a);
		System.out.println("variable a="+a);
		System.out.println("a+b="+a+b); 			//a+b=24
		System.out.println("a+b="+(a+b));	 		//a+b=6
		
		//int a;	//Error no puede volver a declararse la variable a
		a=6;
		a=9;
		a=12;
		System.out.println(a);
		
		// variables String
		String r="Recreo";
		String j="Cafe";
		
		System.out.println(r+j);
		System.out.println(r+" "+j);
		System.out.println(r+" y "+j);
		
		// variables char
		char h='p';
		System.out.println(h);
		h=65;
		System.out.println(h);
		
		// variables float 32 bits
		float fl=9.56f;
		
		// variables double 64 bits
		double dl=9.56;
		
		fl=10;
		dl=10;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		// Tipo de datos boolean
		boolean x=true;
		System.out.println(x);
		
		x=false;
		System.out.println(x);
		
		// Operadores
		
		// Operador de asignación		=
		int nro1=5;
		int nro2=7;
		
		System.out.println(nro1+" "+nro2);
		
		nro1 = nro2;
		// <---
		
		System.out.println(nro1+" "+nro2);
		
		// Operadores Incrementales	++ -- += -= *= /=
		nro1++;			// nro1=nro1+1
		System.out.println(nro1);
		
		nro1--;			// nro1=nro1-1
		System.out.println(nro1);
		
		nro1 += 5;		// nro1=nro1+5;
		System.out.println(nro1);
		
		nro1-=5; 		// nro1=nro1-5;
		System.out.println(nro1);
		
		nro1*=5;		// nro1=nro1*5;
		System.out.println(nro1);
		
		nro1/=5;		// nro1=nro1/5;
		System.out.println(nro1);
		
		// precedencia y procedencia de operadores binarios ++ --
		System.out.println(nro1++);
		System.out.println(nro1);
		System.out.println(++nro1);
		
		/*
		 	Operadores Relacionales 
		 	
		 	==			Equals (Comparación)
		 	!=			Not Equals	(No Igual)
		 	!			Not
		 	< <= >= >
		 	
		 */
		
		System.out.println(nro1==9);			//true
		System.out.println(nro1==10);			//false
		
		System.out.println(nro1!=9);			//false
		System.out.println(nro1!=10);			//true
		
		System.out.println(nro1<9);				//false
		System.out.println(nro1<=9);			//true
		
		boolean log1=true;
		boolean log2=false;
		
		System.out.println(log1); 				//true
		System.out.println(!log1); 				//false
		System.out.println(!!log1);				//true
		System.out.println(!!!log1);			//false
		System.out.println(!!!!log1); 			//true 
		
		/*
		 	Operadores Logicos
		 	
		 	&&		AND				//shift 6
		 	||		OR				//altgr 1
		 */
		
		/*
		 
		 	Tabla de Verdad
		 	
		 	X	Y			OR			AND
		 	F	F			F			F
		 	F	V			V			F
		 	V	F			V			F
		 	V	V			V			V
		 
		 */
		
		System.out.println(log1 || log2); 			//true
		System.out.println(log1 && log2); 			//false
		
		
		// Desarrollar más expresiones logicas
		
	}

}
